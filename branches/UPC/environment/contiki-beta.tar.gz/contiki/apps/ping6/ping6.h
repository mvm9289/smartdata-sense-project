#ifndef __PING6_H__
#define __PING6_H__

#include "contiki.h"

PROCESS_NAME(ping6_process);

#endif /* __PING6_H__ */
