#include "contiki.h"

PROCESS_NAME(ppp_process);
