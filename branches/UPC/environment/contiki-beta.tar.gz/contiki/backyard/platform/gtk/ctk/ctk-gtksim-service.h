#ifndef __CTK_GTKSIM_SERVICE_H__
#define __CTK_GTKSIM_SERVICE_H__

#include "contiki.h"

PROCESS_NAME(ctk_gtksim_service_process);

#endif /* __CTK_GTKSIM_SERVICE_H__ */
