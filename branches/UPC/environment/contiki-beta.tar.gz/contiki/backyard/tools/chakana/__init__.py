"""Chakana, an automated test harness for networked embedded systems."""
