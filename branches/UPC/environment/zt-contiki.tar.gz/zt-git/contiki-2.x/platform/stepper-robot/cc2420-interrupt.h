#ifndef __CC2420_CORE_INTERRUPT_H__9499CTDNSK__
#define __CC2420_CORE_INTERRUPT_H__9499CTDNSK__

void
cc2420_interrupt_fifop_int_init(void);
#endif /* __CC2420_CORE_INTERRUPT_H__9499CTDNSK__ */
