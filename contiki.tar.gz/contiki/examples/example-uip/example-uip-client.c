#include "contiki-net.h"
#include <stdio.h>
#include <string.h>

PROCESS(example_uip_client_process, "Example uip client");
AUTOSTART_PROCESSES(&example_uip_client_process);

PROCESS_THREAD(example_uip_client_process, ev, data)
{
  struct uip_udp_conn *c;
  uip_ipaddr_t ipaddr_server;
  uip_ipaddr_t ipaddr_client;
  //uip_ipaddr_t ipaddr_aux;
  //char buffer[50];
  char first;

  PROCESS_BEGIN();

  /* Node IP address configuration */
  uip_ipaddr(&ipaddr_client, 192,168,1,3);
  uip_sethostaddr(&ipaddr_client);

  //uip_gethostaddr(&ipaddr_aux);
  //printf("%d.%d.%d.%d\n", ipaddr_aux.u8[0],ipaddr_aux.u8[1], ipaddr_aux.u8[2], ipaddr_aux.u8[3]);

  /* Connecting to the server at port */
  uip_ipaddr(&ipaddr_server, 192,168,1,2);
  c = uip_connect(&ipaddr_server, UIP_HTONS(80));
  if (c != NULL) 
    printf("Connection reserved\n");
  
  first = 1;    
      
  while(1) {
    if(uip_connected()) {
      printf("Connected\n");      
      if (first == 1) {
        uip_send("Hello\n", 6);
        printf("'Hello' sended\n");
        first = 0;
      }
      else if (uip_acked() || uip_rexmit()) {
        printf("Ack received\n");
        uip_send("Hello\n", 6);
        printf("'Hello' sended\n");
      }
    }
  }
  
  PROCESS_END();
}
