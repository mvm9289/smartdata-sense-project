#include "contiki-net.h"
#include "dev/leds.h"
#include <stdio.h>
#include <string.h>

PROCESS(example_uip_server_process, "Example uip server");
AUTOSTART_PROCESSES(&example_uip_server_process);

PROCESS_THREAD(example_uip_server_process, ev, data)
{
  uip_ipaddr_t ipaddr_server;
  //uip_ipaddr_t ipaddr_aux;
  char buffer[50];
  
  PROCESS_BEGIN();
  
  /* IP address configuration */
  uip_ipaddr(&ipaddr_server, 192,168,1,2);
  uip_sethostaddr(&ipaddr_server);
  
  //uip_gethostaddr(&ipaddr_aux);
  //printf("%d.%d.%d.%d\n", ipaddr_aux.u8[0],ipaddr_aux.u8[1], ipaddr_aux.u8[2], ipaddr_aux.u8[3]);
  
  /* Listening requests on port 1234 */
  uip_listen(UIP_HTONS(80));
  
  while(1) {
    if(uip_connected()) {
      printf("Connected\n");
      if(uip_newdata() || uip_rexmit()) {
        /* Sengind server response */
        uip_send((void *)"Ok\n", 3);
        printf("'Ok' sended");
      }
    }
  }
  
  PROCESS_END();
}
