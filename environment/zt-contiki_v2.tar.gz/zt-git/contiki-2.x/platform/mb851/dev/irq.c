void
irq_init(void)
{
}

