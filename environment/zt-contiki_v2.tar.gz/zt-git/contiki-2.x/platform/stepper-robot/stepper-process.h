#ifndef __STEPPER_PROCESS_H__1OAHVG2XPP__
#define __STEPPER_PROCESS_H__1OAHVG2XPP__
#include <sys/process.h>

PROCESS_NAME(stepper_process);

#endif /* __STEPPER_PROCESS_H__1OAHVG2XPP__ */
