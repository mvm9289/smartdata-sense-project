


int main() {

float flottant					;
// char c;
scanf("%f" , &flottant);
// scanf("%c",&c);
  //while(1);
  return 0;

 }

