/** @file hal/micro/cortexm3/mpu.h
 *
 * <!--(C) COPYRIGHT 2010 STMicroelectronics. All rights reserved.        -->
 */


#ifndef __MPU_H__
#define __MPU_H__

#define BYPASS_MPU(blah) blah

#endif//__MPU_H__
