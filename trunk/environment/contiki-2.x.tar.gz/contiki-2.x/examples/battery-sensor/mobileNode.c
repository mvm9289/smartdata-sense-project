#include "contiki.h"

#include "dev/battery-sensor.h"
#include "net/rime.h"
#include "net/rime/mesh.h"
#include "leds.h"

#include <stdio.h>
#include <string.h>

#define SINK_ADDR1 111
#define SINK_ADDR2 111
#define CHANNEL 111
#define TIME 30
#define MAX_ATTEMPTS 2
#define TEMP_BUFFER_SIZE 16

/*--------------------------------------------------------------------*/
PROCESS(aplicacio, "Aplicacio de prova");
AUTOSTART_PROCESSES(&aplicacio);
/*--------------------------------------------------------------------*/
static struct mesh_conn app_conn;
static struct etimer timer;
static int temp_bytes;
static unsigned char temp_buffer[TEMP_BUFFER_SIZE];
static int attempts;
static rimeaddr_t sink_addr;

static void sent(struct mesh_conn *c)
{
    printf("Packet sent\n");
    leds_off(LEDS_RED);
}

static void timedout(struct mesh_conn *c)
{
attempts++;
	if (attempts < MAX_ATTEMPTS) 
	{
   		printf("Timedout: resending packet\n");        
	    packetbuf_copyfrom((void*)temp_buffer, temp_bytes);
        sink_addr.u8[0] = SINK_ADDR1;
        sink_addr.u8[1] = SINK_ADDR2;
        mesh_send(&app_conn, &sink_addr);   
	}
	else
	{
		printf("Maximum number of attempts reached\n");        
        leds_on(LEDS_RED);
	}
}

static void received(struct mesh_conn *c, const rimeaddr_t *from, uint8_t hops)
{
}

const static struct mesh_callbacks app_sink_callbacks = {received, sent, timedout};

/*--------------------------------------------------------------------*/
PROCESS_THREAD(aplicacio, ev, data)
{

  PROCESS_EXITHANDLER(mesh_close(&app_conn);)
  PROCESS_BEGIN();
  
  SENSORS_ACTIVATE(battery_sensor);
  
  rimeaddr_t my_addr;
  my_addr.u8[0] = MY_ADDR1;
  my_addr.u8[1] = MY_ADDR2;
  rimeaddr_set_node_addr(&my_addr);

  mesh_open(&app_conn, CHANNEL, &app_sink_callbacks);
  etimer_set(&timer, TIME*CLOCK_SECOND);
  
  while (1)
  {
    PROCESS_WAIT_EVENT();
    if(ev == PROCESS_EVENT_TIMER )
    {
        uint16_t bateria = battery_sensor.value(0);
  
        printf("Battery: %i\n", bateria);
        
        temp_bytes = sprintf(temp_buffer, "%i", bateria);
        
        packetbuf_copyfrom((void*)temp_buffer, temp_bytes);
        printf("Sending packet\n");
        attempts = 0;			
        sink_addr.u8[0] = SINK_ADDR1;
        sink_addr.u8[1] = SINK_ADDR2;
        mesh_send(&app_conn, &sink_addr);     
        
        etimer_reset(&timer);
    }
    
  }
  
  SENSORS_DEACTIVATE(battery_sensor);
  
  
  PROCESS_END();
}
/*---------------------------------------------------------------------------*/

