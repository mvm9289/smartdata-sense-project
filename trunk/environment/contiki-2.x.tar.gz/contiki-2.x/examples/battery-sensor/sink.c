#include "contiki.h"

#include "dev/battery-sensor.h"
#include "net/rime.h"
#include "net/rime/mesh.h"

#include <stdio.h>
#include <string.h>


#define MY_ADDR1 111
#define MY_ADDR2 111
#define CHANNEL 111
#define TIME 60

/*--------------------------------------------------------------------*/
PROCESS(aplicacio, "Aplicacio de prova");
AUTOSTART_PROCESSES(&aplicacio);
/*--------------------------------------------------------------------*/
static struct mesh_conn app_conn;
static struct etimer timer;

static void sent(struct mesh_conn *c)
{

}

static void timedout(struct mesh_conn *c)
{
}

static void received(struct mesh_conn *c, const rimeaddr_t *from, uint8_t hops)
{
	printf("Packet received:\n From: %d.%d\n Data length: %d\n Data: Battery =  %.*s\n Hops: %d\n\n",
			from->u8[0], from->u8[1], packetbuf_datalen(),
			packetbuf_datalen(), (char *)packetbuf_dataptr(), hops);


}

const static struct mesh_callbacks app_sink_callbacks = {received, sent, timedout};

/*--------------------------------------------------------------------*/
PROCESS_THREAD(aplicacio, ev, data)
{

  PROCESS_EXITHANDLER(mesh_close(&app_conn);)
  PROCESS_BEGIN();
  
  SENSORS_ACTIVATE(battery_sensor);
  
  rimeaddr_t my_addr;
  my_addr.u8[0] = MY_ADDR1;
  my_addr.u8[1] = MY_ADDR2;
  rimeaddr_set_node_addr(&my_addr);

  mesh_open(&app_conn, CHANNEL, &app_sink_callbacks);
  etimer_set(&timer, TIME*CLOCK_SECOND);
  
  while (1)
  {
    PROCESS_WAIT_EVENT();
    if(ev == PROCESS_EVENT_TIMER )
    {
        uint16_t bateria = battery_sensor.value(0);
  
        printf("Battery: %i\n", bateria);
        
        etimer_reset(&timer);
    }
    
  }
  
  SENSORS_DEACTIVATE(battery_sensor);
  
  
  PROCESS_END();
}
/*---------------------------------------------------------------------------*/

